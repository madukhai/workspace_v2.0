
function titleCaseFilter(){
	return function(inputString){
		return inputString.charAt(0).toUpperCase() + inputString.slice(1);
	}
}


angular.module('insultApp').filter('titleCaseFilter', titleCaseFilter);